# Dr. Cinema - Group 25

## Description

Dr. Cinema is the third assignment in the App Development course in RU, fall semester 2020.
We are making an application that displays movies that are currently playing in cinemas.
It also shows upcoming movies that have not yet been released.
The whole application is in Icelandic.
We are using an external API to get the correct information.

## The Team

The team consists of 3 people:

- [Margrét Sól Aðalsteinsdóttir](mailto:margreta19@ru.is)
- [Róslín Erla Tómasdóttir](mailto:roslin19@ru.is)
- [Svanhildur Einarsdóttir](mailto:svanhildur19@ru.is)

## Extra functionality

- Possible to watch trailers
- Rating visible for Detailed view from all movies
- All sorts of extra information in detailed views of movies
- Can see all movies in a list
- Search functionality in large lists
