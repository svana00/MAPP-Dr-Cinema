# MAPP Group 25

## Description

Third assignment in the App Development course in RU, fall semester 2020.
We are making a cinema application.

The team consists of 3 people:

- [Margrét Sól Aðalsteinsdóttir](mailto:margreta19@ru.is)
- [Róslín Erla Tómasdóttir](mailto:roslin19@ru.is)
- [Svanhildur Einarsdóttir](mailto:svanhildur19@ru.is)
