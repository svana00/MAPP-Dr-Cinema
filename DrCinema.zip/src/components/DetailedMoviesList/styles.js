import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  listContainer: {
    paddingBottom: 120,
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
  },
});
