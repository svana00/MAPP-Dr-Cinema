import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  listContainer: {
    paddingBottom: 122,
  },
  text: {
    fontSize: 20,
    color: '#101010',
    marginTop: 30,
    fontWeight: '700',
  },
});
